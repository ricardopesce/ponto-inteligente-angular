import { MascaraDirective } from './mascara.directive';

describe('MascaraDirective', () => {
  it('should create an instance', () => {
    const directive = new MascaraDirective();
    expect(directive).toBeTruthy();
  });
});
