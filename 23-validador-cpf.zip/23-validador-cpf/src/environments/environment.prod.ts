export const environment = {
  production: true,
  baseUrl: 'https://dominio-api.com/',
  baseApiUrl: 'https://dominio-api.com/api/'
};
