export * from './tipo.enum';
